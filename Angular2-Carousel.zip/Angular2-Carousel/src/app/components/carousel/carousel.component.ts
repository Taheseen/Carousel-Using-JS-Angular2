import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.css']
})
export class CarouselComponent implements OnInit {
  slides: Array<any> = [ ]; slide: any;
  counter: number;
  itemToShow;
  items: Array<any> = [
    { image: '/assets/img/images2.jpg', caption: 'Take time to do what makes your soul happy' },
    { image: '/assets/img/images1.jpg', caption: 'Let your faith be bigger than your fear' },
    { image: '/assets/img/images3.jpg', caption: 'The best revenge is massive success' },
    { image: '/assets/img/images4.jpg', caption: 'Let your faith be bigger than your fear' },
    { image: '/assets/img/images5.jpg', caption: 'Take time to do what makes your soul happy' },
    { image: '/assets/img/images6.jpg', caption: 'The best revenge is massive success' }
  ];
  constructor() {
   }

  ngOnInit() {
    this.counter = 0;
    this.slide = this.items[0];
    this.populateArrayWithDelay();
  }

private getIndexNumber() {
    this.itemToShow = Math.abs( this.counter % (this.items.length));
}
populateArrayWithDelay(): void {
    for (let i = 0; i < this.items.length; i++) {
         setTimeout(() => {
          this.getIndexNumber();
            i = this.itemToShow;
             this.slides.splice(0, 1, this.items[i]);
             if (i !== this.items.length ) {
              this.counter += 1;
             }
        }, 2500 * ( i + 1 ));
    }
}

private getSlideByIndex ( index: number) {
  for (let i = 0; i < this.items.length; ++i) {
      if (i === index) {
        console.log(i, 'i in getbyindex');
        this.slides.splice(0, 1, this.items[i]);
     }
  }
}

tapNext() {
  this.counter += 1;
  this.getIndexNumber();
  this.getSlideByIndex(this.itemToShow);
  event.preventDefault();
  return false;
}

tapPrev() {
  this.counter -= 1;
  this.getIndexNumber();
  this.getSlideByIndex(this.itemToShow);
  event.preventDefault();
  return false;
}


}
