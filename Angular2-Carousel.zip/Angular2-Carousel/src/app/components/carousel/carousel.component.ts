import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.css']
})
export class CarouselComponent implements OnInit {
  slides: Array<any> = [ ]; slide: any;
  counter: number; itemNo: number;
  itemToShow;
  isPlaying;
  items: Array<any> = [
    { id: 1, image: '/assets/img/images2.jpg', caption: 'Take time to do what makes your soul happy' },
    { id: 2, image: '/assets/img/images1.jpg', caption: 'Let your faith be bigger than your fear' },
    { id: 3, image: '/assets/img/images3.jpg', caption: 'The best revenge is massive success' },
    { id: 4, image: '/assets/img/images4.jpg', caption: 'Let your faith be bigger than your fear' },
    { id: 5, image: '/assets/img/images5.jpg', caption: 'Take time to do what makes your soul happy' },
    { id: 6, image: '/assets/img/images6.jpg', caption: 'The best revenge is massive success' }
  ];
  constructor() {
   }

  ngOnInit() {
    this.counter = 0;
    this.slide = this.items[0];
    this.itemNo = 0;
    this.populateArrayWithDelay(this.itemNo);
  }

private getIndexNumber() {
    this.itemToShow = Math.abs( this.counter % (this.items.length));
}

populateArrayWithDelay(itemNo): void {
    for (itemNo; itemNo < this.items.length; itemNo++) {
         setTimeout(() => {
          this.getIndexNumber();
          itemNo = this.itemToShow;
             this.slides.splice(0, 1, this.items[itemNo]);
             if (itemNo !== this.items.length ) {
              this.counter += 1;
             }
        }, 2500 * ( itemNo + 1 ));
    }
}

private getSlideByIndex ( index: number) {
  for (let i = 0; i < this.items.length; ++i) {
      if (i === index) {
        console.log(i, 'i in getbyindex');
        this.slides.splice(0, 1, this.items[i]);
     }
  }
}

tapNext() {
  this.counter += 1;
  this.getIndexNumber();
  this.getSlideByIndex(this.itemToShow);
  event.preventDefault();
  return false;
}

tapPrev() {
  this.counter -= 1;
  this.getIndexNumber();
  this.getSlideByIndex(this.itemToShow);
  event.preventDefault();
  return false;
}
clicked(slide) {
  this.slides.splice(0, 1, slide);
  this.populateArrayWithDelay(slide.id);
}
playOrPause() {
  console.log('tapped on play or pause button');
}
}
