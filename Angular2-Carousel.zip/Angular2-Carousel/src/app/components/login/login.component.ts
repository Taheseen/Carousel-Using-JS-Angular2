import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: any = {};
  valid: boolean;
  constructor(
      private router: Router
  ) {  }

  ngOnInit() {
  }

  login() {
    console.log(this.user);
    // this.auth.login(this.user.username, this.user.password);
    // this.valid = this.auth.login(this.user.username, this.user.password);
    if (this.valid === true) {
      this.router.navigateByUrl('/todo');
    }else {
      console.log('Invalid Login!');
    }
  }
}
