import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  user: any = {};
  valid: boolean;
  dt;
  constructor() {  this.user.date = new Date(); }

  ngOnInit() {
  }

  searchFlight() {
    console.log(this.user);
    //  if (this.valid === true) {
    //   console.log('Form valid');
    // }else {
    //   console.log('Invalid Login!');
    // }
  }

}
