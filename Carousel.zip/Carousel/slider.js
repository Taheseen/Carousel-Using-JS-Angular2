var intervalTimer,
	isIntervalClear = false,
	counter = 0,
    slideCurrent = function(){};

function slider(){
	$items = document.querySelectorAll('#slider figure'), 
    numItems = $items.length,
	 slideCurrent = function(){
	  var itemToShow = Math.abs(counter%numItems);
	  [].forEach.call( $items, function(el){
		el.classList.remove('slide');
	  });
	  $items[itemToShow].classList.add('slide');    
	};
	  
	function startSlider(){
		isIntervalClear = true;
		intervalTimer = window.setInterval(function(){
			counter++;
			slideCurrent();
		}, 2500);
	}

//handle tap or click. onclick or ontap the slider will stop
document.addEventListener('mouseup', tapOrClick, false);
document.addEventListener('touchend', tapOrClick, false);

function tapOrClick(event) {
   //handle tap or click.
    if (isIntervalClear) {
			isIntervalClear = false;
			window.clearInterval(intervalTimer);
			intervalTimer = 0;
		} else {
			startSlider();
		}
    event.preventDefault();
    return false;
}
		if (!isIntervalClear) {
			startSlider();
		}	
};

/* Handle tap event on next & prev button */

document.querySelector('.next').addEventListener("mouseup", tapNext, false);
document.querySelector('.next').addEventListener("touchend", tapNext, false);

function tapNext(event) {
    counter++;
    slideCurrent();

    event.preventDefault();
    return false;
};

document.querySelector('.prev').addEventListener("mouseup", tapNext, false);
document.querySelector('.prev').addEventListener("touchend", tapNext, false);

function tapNext(event) {
    counter--;
    slideCurrent();

    event.preventDefault();
    return false;
};











